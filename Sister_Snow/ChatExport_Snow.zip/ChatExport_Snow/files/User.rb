class User
  include Mongoid::Document
  field :uid
  field :nickname
  field :avatar
  field :region
  field :veri_code
  field :expired
  field :expire_time
end